import React from 'react';
import { TrendingUp, Award, AlertCircle, CheckCircle, Target, Lightbulb } from 'lucide-react';
import { AnalysisResult } from '../types';
import ScoreCard from './ScoreCard';

interface RankingResultsProps {
  result: AnalysisResult;
  onNewAnalysis: () => void;
}

const RankingResults: React.FC<RankingResultsProps> = ({ result, onNewAnalysis }) => {
  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreBgColor = (score: number) => {
    if (score >= 80) return 'bg-green-100';
    if (score >= 60) return 'bg-yellow-100';
    return 'bg-red-100';
  };

  return (
    <div className="space-y-8">
      {/* Overall Score Header */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-8 text-center">
        <div className="flex items-center justify-center mb-4">
          <div className={`p-4 rounded-full ${getScoreBgColor(result.overallScore)}`}>
            <Award className={`h-8 w-8 ${getScoreColor(result.overallScore)}`} />
          </div>
        </div>
        <h2 className="text-3xl font-bold text-gray-900 mb-2">Overall Match Score</h2>
        <div className={`text-6xl font-bold mb-4 ${getScoreColor(result.overallScore)}`}>
          {result.overallScore}%
        </div>
        <p className="text-gray-600 text-lg">
          {result.overallScore >= 80 && "Excellent match! This resume strongly aligns with the job requirements."}
          {result.overallScore >= 60 && result.overallScore < 80 && "Good match with room for improvement."}
          {result.overallScore < 60 && "Needs improvement to better align with job requirements."}
        </p>
      </div>

      {/* Detailed Scores */}
      <div className="grid md:grid-cols-2 xl:grid-cols-4 gap-6">
        <ScoreCard
          title="Skills Match"
          score={result.skillsMatch.score}
          icon={<Target className="h-6 w-6" />}
          details={`${result.skillsMatch.matched.length} matched, ${result.skillsMatch.missing.length} missing`}
        />
        <ScoreCard
          title="Experience"
          score={result.experienceMatch.score}
          icon={<TrendingUp className="h-6 w-6" />}
          details={result.experienceMatch.feedback}
        />
        <ScoreCard
          title="Education"
          score={result.educationMatch.score}
          icon={<Award className="h-6 w-6" />}
          details={result.educationMatch.feedback}
        />
        <ScoreCard
          title="Certifications"
          score={result.certificationsMatch.score}
          icon={<CheckCircle className="h-6 w-6" />}
          details={`${result.certificationsMatch.matched.length} relevant certifications`}
        />
      </div>

      {/* Detailed Analysis */}
      <div className="grid lg:grid-cols-2 gap-8">
        {/* Strengths */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center space-x-3 mb-6">
            <div className="p-2 bg-green-100 rounded-lg">
              <CheckCircle className="h-6 w-6 text-green-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900">Strengths</h3>
          </div>
          <div className="space-y-3">
            {result.strengths.map((strength, index) => (
              <div key={index} className="flex items-start space-x-3">
                <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                <p className="text-gray-700">{strength}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Recommendations */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
          <div className="flex items-center space-x-3 mb-6">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Lightbulb className="h-6 w-6 text-blue-600" />
            </div>
            <h3 className="text-xl font-semibold text-gray-900">Recommendations</h3>
          </div>
          <div className="space-y-3">
            {result.recommendations.map((recommendation, index) => (
              <div key={index} className="flex items-start space-x-3">
                <AlertCircle className="h-5 w-5 text-blue-500 mt-0.5 flex-shrink-0" />
                <p className="text-gray-700">{recommendation}</p>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Skills Breakdown */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <h3 className="text-xl font-semibold text-gray-900 mb-6">Skills Analysis</h3>
        <div className="grid md:grid-cols-2 gap-6">
          <div>
            <h4 className="font-medium text-green-800 mb-3 flex items-center">
              <CheckCircle className="h-4 w-4 mr-2" />
              Matched Skills ({result.skillsMatch.matched.length})
            </h4>
            <div className="flex flex-wrap gap-2">
              {result.skillsMatch.matched.map((skill, index) => (
                <span
                  key={index}
                  className="px-3 py-1 bg-green-100 text-green-800 rounded-full text-sm"
                >
                  {skill}
                </span>
              ))}
            </div>
          </div>
          <div>
            <h4 className="font-medium text-red-800 mb-3 flex items-center">
              <AlertCircle className="h-4 w-4 mr-2" />
              Missing Skills ({result.skillsMatch.missing.length})
            </h4>
            <div className="flex flex-wrap gap-2">
              {result.skillsMatch.missing.map((skill, index) => (
                <span
                  key={index}
                  className="px-3 py-1 bg-red-100 text-red-800 rounded-full text-sm"
                >
                  {skill}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Action Button */}
      <div className="text-center">
        <button
          onClick={onNewAnalysis}
          className="bg-blue-600 text-white px-8 py-3 rounded-lg font-medium hover:bg-blue-700 transition-colors duration-200"
        >
          Analyze Another Resume
        </button>
      </div>
    </div>
  );
};

export default RankingResults;