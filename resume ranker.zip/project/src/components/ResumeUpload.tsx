import React, { useState, useRef } from 'react';
import { Upload, FileText, CheckCircle, X } from 'lucide-react';
import { ResumeData } from '../types';

interface ResumeUploadProps {
  onUpload: (data: ResumeData) => void;
  hasData: boolean;
}

const ResumeUpload: React.FC<ResumeUploadProps> = ({ onUpload, hasData }) => {
  const [isDragging, setIsDragging] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [uploadedFile, setUploadedFile] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
    const files = e.dataTransfer.files;
    if (files[0]) {
      processFile(files[0]);
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (files && files[0]) {
      processFile(files[0]);
    }
  };

  const processFile = async (file: File) => {
    setIsProcessing(true);
    setUploadedFile(file.name);

    // Simulate file processing
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Mock resume parsing - in real app, this would use actual parsing
    const mockResumeData: ResumeData = {
      fileName: file.name,
      content: "Sample resume content...",
      skills: ["JavaScript", "React", "Python", "SQL", "Project Management", "Communication"],
      experience: ["Frontend Developer at TechCorp (2022-2024)", "Junior Developer at StartupXYZ (2020-2022)"],
      education: ["Bachelor's in Computer Science, State University (2020)"],
      certifications: ["AWS Certified Developer", "Google Analytics Certified"]
    };

    onUpload(mockResumeData);
    setIsProcessing(false);
  };

  const handleClick = () => {
    fileInputRef.current?.click();
  };

  if (hasData) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-semibold text-gray-800">Resume Uploaded</h2>
          <CheckCircle className="h-6 w-6 text-green-500" />
        </div>
        <div className="flex items-center space-x-3 p-4 bg-green-50 rounded-lg">
          <FileText className="h-8 w-8 text-green-600" />
          <div>
            <p className="font-medium text-green-800">{uploadedFile}</p>
            <p className="text-sm text-green-600">Successfully processed</p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <h2 className="text-xl font-semibold text-gray-800 mb-6">Upload Resume</h2>
      
      <div
        className={`border-2 border-dashed rounded-xl p-8 text-center transition-all duration-200 cursor-pointer ${
          isDragging 
            ? 'border-blue-400 bg-blue-50' 
            : 'border-gray-300 hover:border-blue-400 hover:bg-gray-50'
        }`}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        onClick={handleClick}
      >
        <input
          ref={fileInputRef}
          type="file"
          accept=".pdf,.doc,.docx,.txt"
          onChange={handleFileSelect}
          className="hidden"
        />
        
        {isProcessing ? (
          <div className="flex flex-col items-center">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mb-4"></div>
            <p className="text-gray-600">Processing resume...</p>
          </div>
        ) : (
          <div className="flex flex-col items-center">
            <div className="p-3 bg-blue-100 rounded-full mb-4">
              <Upload className="h-8 w-8 text-blue-600" />
            </div>
            <h3 className="text-lg font-medium text-gray-800 mb-2">
              Drop your resume here
            </h3>
            <p className="text-gray-600 mb-4">
              or click to browse files
            </p>
            <p className="text-sm text-gray-500">
              Supports PDF, DOC, DOCX, TXT files
            </p>
          </div>
        )}
      </div>
    </div>
  );
};

export default ResumeUpload;