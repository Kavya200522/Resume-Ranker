import React, { useState } from 'react';
import Header from './components/Header';
import ResumeUpload from './components/ResumeUpload';
import JobRequirements from './components/JobRequirements';
import RankingResults from './components/RankingResults';
import { analyzeResume } from './utils/resumeRanker';
import { ResumeData, JobRequirements as JobReqs, AnalysisResult } from './types';

function App() {
  const [resumeData, setResumeData] = useState<ResumeData | null>(null);
  const [jobRequirements, setJobRequirements] = useState<JobReqs | null>(null);
  const [analysisResult, setAnalysisResult] = useState<AnalysisResult | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const handleResumeUpload = (data: ResumeData) => {
    setResumeData(data);
    if (jobRequirements) {
      performAnalysis(data, jobRequirements);
    }
  };

  const handleJobRequirements = (requirements: JobReqs) => {
    setJobRequirements(requirements);
    if (resumeData) {
      performAnalysis(resumeData, requirements);
    }
  };

  const performAnalysis = async (resume: ResumeData, requirements: JobReqs) => {
    setIsAnalyzing(true);
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 2000));
    const result = analyzeResume(resume, requirements);
    setAnalysisResult(result);
    setIsAnalyzing(false);
  };

  const handleReset = () => {
    setResumeData(null);
    setJobRequirements(null);
    setAnalysisResult(null);
    setIsAnalyzing(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <Header onReset={handleReset} />
      
      <main className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          {!analysisResult && !isAnalyzing && (
            <div className="grid lg:grid-cols-2 gap-8 mb-8">
              <ResumeUpload 
                onUpload={handleResumeUpload}
                hasData={!!resumeData}
              />
              <JobRequirements 
                onSubmit={handleJobRequirements}
                hasData={!!jobRequirements}
              />
            </div>
          )}

          {isAnalyzing && (
            <div className="flex items-center justify-center py-20">
              <div className="text-center">
                <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600 mx-auto mb-4"></div>
                <h3 className="text-xl font-semibold text-gray-800 mb-2">Analyzing Resume</h3>
                <p className="text-gray-600">Our AI is carefully reviewing your resume against the job requirements...</p>
              </div>
            </div>
          )}

          {analysisResult && (
            <RankingResults 
              result={analysisResult}
              onNewAnalysis={handleReset}
            />
          )}
        </div>
      </main>
    </div>
  );
}

export default App;