import { ResumeData, JobRequirements, AnalysisResult } from '../types';

export function analyzeResume(resume: ResumeData, requirements: JobRequirements): AnalysisResult {
  // Calculate skills match
  const skillsMatch = calculateSkillsMatch(resume.skills, requirements.requiredSkills, requirements.preferredSkills);
  
  // Calculate experience match
  const experienceMatch = calculateExperienceMatch(resume.experience, requirements.experienceLevel);
  
  // Calculate education match
  const educationMatch = calculateEducationMatch(resume.education, requirements.education);
  
  // Calculate certifications match
  const certificationsMatch = calculateCertificationsMatch(resume.certifications, requirements.certifications);
  
  // Calculate overall score (weighted average)
  const overallScore = Math.round(
    (skillsMatch.score * 0.4) + 
    (experienceMatch.score * 0.3) + 
    (educationMatch.score * 0.2) + 
    (certificationsMatch.score * 0.1)
  );

  // Generate recommendations and strengths
  const recommendations = generateRecommendations(skillsMatch, experienceMatch, educationMatch, certificationsMatch);
  const strengths = generateStrengths(skillsMatch, experienceMatch, educationMatch, certificationsMatch);

  return {
    overallScore,
    skillsMatch,
    experienceMatch,
    educationMatch,
    certificationsMatch,
    recommendations,
    strengths
  };
}

function calculateSkillsMatch(resumeSkills: string[], requiredSkills: string[], preferredSkills: string[]) {
  const allRequiredSkills = [...requiredSkills, ...preferredSkills];
  const matched: string[] = [];
  const missing: string[] = [];

  // Check for skill matches (case-insensitive)
  allRequiredSkills.forEach(skill => {
    const isMatched = resumeSkills.some(resumeSkill => 
      resumeSkill.toLowerCase().includes(skill.toLowerCase()) ||
      skill.toLowerCase().includes(resumeSkill.toLowerCase())
    );

    if (isMatched) {
      matched.push(skill);
    } else {
      missing.push(skill);
    }
  });

  // Calculate score based on required vs preferred skills
  const requiredMatched = matched.filter(skill => 
    requiredSkills.some(req => req.toLowerCase() === skill.toLowerCase())
  ).length;
  
  const preferredMatched = matched.filter(skill => 
    preferredSkills.some(pref => pref.toLowerCase() === skill.toLowerCase())
  ).length;

  const requiredScore = requiredSkills.length > 0 ? (requiredMatched / requiredSkills.length) * 80 : 80;
  const preferredScore = preferredSkills.length > 0 ? (preferredMatched / preferredSkills.length) * 20 : 20;
  
  const score = Math.round(requiredScore + preferredScore);

  return { score: Math.min(score, 100), matched, missing };
}

function calculateExperienceMatch(experience: string[], requiredLevel: string) {
  // Simple heuristic based on number of experiences and level
  const experienceCount = experience.length;
  let score = 50; // Base score
  let feedback = '';

  switch (requiredLevel) {
    case 'Entry Level':
      score = experienceCount >= 1 ? 90 : 60;
      feedback = experienceCount >= 1 ? 'Good entry-level experience' : 'Limited experience for entry level';
      break;
    case 'Mid Level':
      score = experienceCount >= 2 ? 85 : experienceCount >= 1 ? 70 : 50;
      feedback = experienceCount >= 2 ? 'Strong mid-level experience' : 'May need more experience for mid-level';
      break;
    case 'Senior Level':
      score = experienceCount >= 3 ? 90 : experienceCount >= 2 ? 75 : 60;
      feedback = experienceCount >= 3 ? 'Excellent senior-level experience' : 'Could benefit from more senior experience';
      break;
    case 'Lead/Principal':
      score = experienceCount >= 4 ? 95 : experienceCount >= 3 ? 80 : 65;
      feedback = experienceCount >= 4 ? 'Outstanding leadership experience' : 'May need more leadership experience';
      break;
    default:
      feedback = 'Experience level assessment needed';
  }

  return { score, feedback };
}

function calculateEducationMatch(education: string[], requiredEducation: string) {
  const educationLevels = {
    'High School': 1,
    'Associate Degree': 2,
    'Bachelor\'s Degree': 3,
    'Master\'s Degree': 4,
    'PhD': 5
  };

  const resumeLevel = Math.max(...education.map(edu => {
    for (const [level, value] of Object.entries(educationLevels)) {
      if (edu.toLowerCase().includes(level.toLowerCase())) {
        return value;
      }
    }
    return 1;
  }));

  const requiredLevel = educationLevels[requiredEducation as keyof typeof educationLevels] || 3;
  
  let score = 50;
  let feedback = '';

  if (resumeLevel >= requiredLevel) {
    score = 90;
    feedback = 'Meets education requirements';
  } else if (resumeLevel === requiredLevel - 1) {
    score = 70;
    feedback = 'Close to education requirements';
  } else {
    score = 50;
    feedback = 'Below education requirements';
  }

  return { score, feedback };
}

function calculateCertificationsMatch(resumeCerts: string[], requiredCerts: string[]) {
  const matched: string[] = [];
  const missing: string[] = [];

  requiredCerts.forEach(cert => {
    const isMatched = resumeCerts.some(resumeCert => 
      resumeCert.toLowerCase().includes(cert.toLowerCase()) ||
      cert.toLowerCase().includes(resumeCert.toLowerCase())
    );

    if (isMatched) {
      matched.push(cert);
    } else {
      missing.push(cert);
    }
  });

  const score = requiredCerts.length > 0 ? Math.round((matched.length / requiredCerts.length) * 100) : 100;

  return { score, matched, missing };
}

function generateRecommendations(skillsMatch: any, experienceMatch: any, educationMatch: any, certificationsMatch: any): string[] {
  const recommendations: string[] = [];

  if (skillsMatch.missing.length > 0) {
    recommendations.push(`Consider developing skills in: ${skillsMatch.missing.slice(0, 3).join(', ')}`);
  }

  if (experienceMatch.score < 70) {
    recommendations.push('Highlight relevant project experience and achievements to strengthen your profile');
  }

  if (educationMatch.score < 70) {
    recommendations.push('Consider pursuing additional education or professional development courses');
  }

  if (certificationsMatch.missing.length > 0) {
    recommendations.push(`Obtaining certifications in ${certificationsMatch.missing[0]} would strengthen your application`);
  }

  if (skillsMatch.score > 80) {
    recommendations.push('Consider highlighting your technical skills more prominently in your resume');
  }

  return recommendations;
}

function generateStrengths(skillsMatch: any, experienceMatch: any, educationMatch: any, certificationsMatch: any): string[] {
  const strengths: string[] = [];

  if (skillsMatch.score >= 80) {
    strengths.push(`Strong technical skill set with ${skillsMatch.matched.length} relevant skills`);
  }

  if (experienceMatch.score >= 80) {
    strengths.push('Solid professional experience aligned with role requirements');
  }

  if (educationMatch.score >= 80) {
    strengths.push('Educational background meets or exceeds requirements');
  }

  if (certificationsMatch.score >= 80) {
    strengths.push('Relevant professional certifications demonstrate commitment to field');
  }

  if (skillsMatch.matched.length > 5) {
    strengths.push('Diverse skill set shows versatility and adaptability');
  }

  return strengths;
}