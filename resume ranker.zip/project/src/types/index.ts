export interface ResumeData {
  fileName: string;
  content: string;
  skills: string[];
  experience: string[];
  education: string[];
  certifications: string[];
}

export interface JobRequirements {
  title: string;
  description: string;
  requiredSkills: string[];
  preferredSkills: string[];
  experienceLevel: string;
  education: string;
  certifications: string[];
}

export interface AnalysisResult {
  overallScore: number;
  skillsMatch: {
    score: number;
    matched: string[];
    missing: string[];
  };
  experienceMatch: {
    score: number;
    feedback: string;
  };
  educationMatch: {
    score: number;
    feedback: string;
  };
  certificationsMatch: {
    score: number;
    matched: string[];
    missing: string[];
  };
  recommendations: string[];
  strengths: string[];
}